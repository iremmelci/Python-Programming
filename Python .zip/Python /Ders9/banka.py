# -*- coding: utf-8 -*-
"""
Created on Sat May 11 17:10:47 2019

@author: uby1
"""


#banka -> kişi, para
# para_cek(), para_yatir(),transfer()
#değerler dosyada tutulacak.
#tutar yetersiz ise uyarı vereceğiz
class Banka():
    def __init__(self,kisi,para):
        self.kisi=kisi
        self.para=para
    def para_cek(self):
        tutar=int(input("Ne kadar para çekeceksiniz:"))
        if self.para<tutar:
            print("Bakiye yetersiz...")
        else:
            self.para-=tutar
            print(tutar," para çekildi. Yeni bakiye:",self.para)
        
    def para_yatir(self):
        tutar=int(input("Ne kadar para yatıracaksınız:"))
        self.para+=tutar
        print(tutar," para yatırıldı. Yeni bakiye:",self.para)
    def para_yatir2(self,para):
        self.para+=para
        print(para," para yatırıldı. Yeni bakiye:",self.para)
    #def yenibakiye(self,tutar):
    #    self.para+=tutar
    def transfer(self):
        tkisi=input("Kime transfer edeceksiniz:")
        tutar=int(input("Ne kadar transfer edeceksiniz:"))
        """
        if tutar<=self.para:
            if tkisi==gozde:
            #tkisi.yenibakiye(tutar)
                self.para-=tutar
                gozde.para+=tutar
                print(tutar," havale edildi.")
                print("Gözde:",gozde.para)
                print(self.kisi,":",self.para)
        """
        else:
            print("Bakiye yetersiz...")
            
        
irem=Banka("irem",10000)
emir=Banka("emir",10000)
gozde=Banka("gozde",0)
#gozde.para_yatir()
#gozde.para_yatir2(1000)

irem.transfer()

