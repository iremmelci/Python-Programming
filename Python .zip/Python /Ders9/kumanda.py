# -*- coding: utf-8 -*-
"""
Created on Sat May 11 14:31:41 2019

@author: Gözde Mihran Altınsoy
"""
import time
class Kumanda():
    
    def __init__(self,tv_durum=False,ses_duzey=10,kanal="Puhu Tv",kanal_listesi=["Puhu Tv","Netflix","TRT 1"]):
        self.tv_durum=tv_durum
        self.ses_duzey=ses_duzey
        self.kanal=kanal
        self.kanal_listesi=kanal_listesi
    def tv_ac(self):
        if (self.tv_durum):
            print("Tv zaten açık...")
        else:
            print("Tv açılıyor..")
            self.tv_durum=True
            time.sleep(1)
            print("Tv açıldı")
    def tv_kapat(self):
        if (self.tv_durum==False):
            print("Tv zaten kapalı...")
        else:
            print("Tv kapatılıyor..")
            self.tv_durum=False
            time.sleep(1)
            print("Tv kapatıldı")
    def kanal_degis(self):
        if self.tv_durum==True:
            print(self.kanal_listesi)
            
            try:
                secim=int(input("Kanal seçiminiz: 0..1..2..3.."))
                self.kanal=self.kanal_listesi[secim]
            except IndexError:
                print("Lütfen geçerli bir kanal giriniz.")
            except ValueError:
                print("Geçersiz bir değer girdiniz.")
            except:
                print("Geçersiz işlem")
        else:
            print("Tv kapalı önce Tv'yi açman gerekiyor.")
    def ses_degis(self):
        ses=int(input("Ses düzeyini girin 1....50 :"))
        if ses<0 or ses>50:
            print("Geçersiz ses düzeyi...")
        else:
            self.ses_duzey=ses
        print("Ses düzeyi:",self.ses_duzey)
    def __str__(self): #print ile nesneyi yazdırmak istediğimizde bu fonksiyon çalışır.
        return "Tv Durum: {}\nKanal: {}\nSes Düzeyi: {}".format(self.tv_durum,self.kanal,self.ses_duzey)
    def __len__(self):
        return len(self.kanal_listesi)
    def kanal_ekle(self,kanal):   
        self.kanal_listesi.append(kanal)
        print(self.kanal_listesi)
    
kumanda=Kumanda()
"""
print("Kumanda durum:",kumanda.tv_durum)
kumanda.tv_ac()
print("Kumanda durum:",kumanda.tv_durum)
kumanda.tv_kapat()        

kumanda.tv_ac()
kumanda.kanal_degis() 
print("Kanal:",kumanda.kanal)       
kumanda.ses_degis()
"""
print(kumanda)
print("Kanal sayısı:",len(kumanda))
kanal=input("Kanal:")
kumanda.kanal_ekle(kanal)

