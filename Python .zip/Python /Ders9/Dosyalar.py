# -*- coding: utf-8 -*-
"""
Created on Sat May 11 15:38:07 2019

@author: Gözde Mihran Altınsoy
"""
"""
open("bilgiler.txt","w")

file=open("bilgiler.txt","w")

file.close()

#file=open("G:/bilgiler.txt","w")
"""
file=open("bilgiler.txt","w",encoding="utf-8")

file.write("İstanbul")
file.write("Gözde")
file.write("İrem")
file.write("Emir")
file = open("bilgiler.txt","a",encoding="utf-8")
file.write("Python")


file=open("bilgiler2.txt","w",encoding="utf-8")
file.write("İstanbul\n")
file.write("Gözde\n")
file.write("İrem\n")
file.write("Emir\n")
file.close()

file=open("bilgiler2.txt","r",encoding="utf-8")

#file.write("Gözde") #Bu işlemde hata verir. Sadece okuma modu olan r ile açtığımız için dosya değiştirilemez

#Soru: Dosya yoksa "dosya bulunamadı" uyarısı versin ve 1 sn bekleyip "yeni dosya oluşturuldu" uyarısı versin ve dosyayı w moduyla dosyayı açalım

from time import sleep
try:
    file=open("bilgiler3.txt","r",encoding="utf-8")
except FileNotFoundError:
    print("Dosya bulunmadı...")
    sleep(1)
    file=open("bilgiler3.txt","w",encoding="utf-8")
    print("Yeni dosya oluşturuldu...")
    
file=open("bilgiler2.txt","r",encoding="utf-8")
for satir in file:
    print(satir)
    
file.close()


file = open("bilgiler2.txt","r",encoding="utf-8")
icerik = file.read() 
print(icerik)


#%%
kelime="11.05.2019"
liste=[]
liste.append(kelime.split("."))
print(liste)

#%%
isimler="Gözde,Emir,İrem,Ayşe,Ali"
liste=[]
liste.append(isimler.split(","))
print(liste)


#%%
liste=["1\n","2\n","3\n"]
liste2=[]
for i in liste:
    liste2.append(i.split("\n")[0])
print(liste2)
#%%
#sayılar adlı dosyaya 1 ile 20 arasında sayıları atayalım. Tek olanları tek_sayilar isimli dosyaya, çift olanları da cift_sayilar isimli dosyaya atayalım
file = open("sayılar.txt","w")
for i in range(1,21):
    file.write(str(i))
    file.write("\n")
file.close()

file = open("sayılar.txt","r")
liste=file.readlines()

print(liste)
file.close()

liste2=[]
for i in liste:
    liste2.append(i.split("\n")[0])
print(liste2)

ciftsayilar,teksayilar=[],[]
for i in liste2:
    if int(i)%2==0:
        ciftsayilar.append(i)
    else:
        teksayilar.append(i)
print("Tek:",teksayilar)
print("Çift:",ciftsayilar)

file = open("tek_sayılar.txt","w")

for i in teksayilar:
    file.write(str(i))
    file.write("\n")
file.close()

file = open("cift_sayılar.txt","w")

for i in ciftsayilar:
    file.write(str(i))
    file.write("\n")
file.close()   

#%%








