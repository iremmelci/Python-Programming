# -*- coding: utf-8 -*-
"""
Created on Sun May  5 15:00:49 2019

@author: gozdemihranaltinsoy
Modül örneği
"""
class Siparis():
    firma=""
    miktar=0
    siparistarih=""
    teslimtarih=""
    ucret=0
