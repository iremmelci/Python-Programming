"""
Bu modül dört işlem gerçekleştirir
"""

def toplama(s1,s2):
    """
    İki sayının toplamını döndürür
    """
    return s1+s2
def cikarma(s1,s2):
    """
    İki sayının farkını döndürür
    """    
    return s1-s2
def carpma(s1,s2):
    """
    İki sayının çarpımını döndürür
    """
    return s1*s2
def bolme(s1,s2):
    """
    İki sayının bölümünü döndürür
    """
    return s1/s2