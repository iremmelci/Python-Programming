# -*- coding: utf-8 -*-
"""
Created on Sat May 11 14:59:25 2019

@author: gozdemihranaltinsoy
"""
"""
Dosya Açma ve Yazma İşlemleri

Dosya Açmak
Bir dosyayı açmak için open() fonksiyonunu kullanıyoruz. Yapısı şu şekildedir;

open(dosya_adı,dosya_erişme_kipi)
Dosya adını istediğimiz isimde verebiliriz. Dosya erişme kipi ise bizim dosya üzerindeki işlemlerimizi belirler.

"w" dosya kipi
Dosyalarımızı açmak ve dosyalarımıza yazmak için "write" anlamına gelen "w" kipini kullanıyoruz. "w" kipi eğer oluşturmak istediğimiz dizinde öyle bir dosya yoksa dosyayı oluşturuyor , eğer öyle bir dosya varsa dosyayı silip tekrar oluşturuyor. Yani, eğer açmak istediğimiz dosyadan zaten varsa ve dosyanın içi doluysa "w" kipi dosyadaki bilgileri silip tekrar oluşturacaktır. (Biraz Tehlikeli)
"""
#%%
open("bilgiler.txt","w") # Dosyayı bulunduğumuz dizinde açıyor. 
file = open("bilgiler.txt","w") # Dosya üzerinde işlem yapacak dosya imlecini file isimli değişkene atıyoruz.

"""
Dosyaları Kapatmak
Bir dosya üzerinde işlem yaptığımızda o dosyayı kapatmak sistem kaynaklarının gereksiz kullanılmaması açısından önemlidir. Çünkü programımız bitse bile dosyanın kapanacağı garanti değildir. Bu yüzden işlerimiz bittiği zaman dosyayı kapatmalıyız.

"""

file.close()  # Dosyayı kapatmak

"""
Eğer bir dosyayı bulunduğumuz dizinde değil de başka bir dizinde açmak istersek, dizinin yolunu özellikle belirtmeliyiz.


"""
#%%
file = open("C:/Users/gozdemihranaltinsoy/Desktop/bilgiler.txt","w") # çalıştırdığımızda masaüstünde bilgiler.txt oluşacaktır.
file.close() # Unutmayalım.

"""
"w" Kipiyle Dosyalara Yazmak
İlk olarak dosyayı "w" kipiyle açıyoruz.
"""
#%%
file = open("bilgiler.txt","w",encoding="utf-8") # Türkçe karakter kullanacaksak encoding="utf-8" parametresini veriyoruz.
file.write("Gözde Mihran Altınsoy") # write fonksiyonu ile dosyamıza yazıyoruz. 21 bytelık yani 21 karakter yazıldı.

file.close()
"""
write fonksiyonuyla dosyamıza herhangi bir şey yazabiliyoruz. Ancak "w" kipi her seferinde dosyayı tekrar oluşturduğu için dosyayı tekrar açtığımızda bilgiler kaybolacaktır.
"""

file = open("bilgiler.txt","w",encoding="utf-8")
file.close()

"""
"a" Kipiyle Dosyalara Yazmak
"append" (ekleme) kelimesinin kısaltması olan "a" kipiyle bir dosyayı açtığımızda , dosya eğer yoksa oluşturulur. Eğer öyle bir dosya mevcut ise, dosya tekrar oluşturulmaz ve dosya imleci dosyanın sonuna giderek dosyaya ekleme yapmamızı sağlar.
"""
file = open("bilgiler.txt","a",encoding="utf-8")
file.write("Gözde Mihran Altınsoy") 
file.close()
#Dosyayı tekrar açalım.
file = open("bilgiler.txt","a",encoding="utf-8")
file.write("İstanbul") # Dosyanın sonuna ekleme yaptık.
file.close()
#Ancak eğer buradaki isimleri dosyalara alt alta yazmak istersek "\n" karakterini kullanmalıyız.
file = open("bilgiler.txt","a",encoding="utf-8")
file.write("Beykoz\n")
file.write("Bugün hava yağmurlu\n")
file.close()

"""
Dosya Okuma İşlemleri
Dosyaları okumak ve verileri almak için "r" kipiyle açmamız gerekiyor. "r" kipiyle açtığımız dosya eğer bulunmuyorsa "FileNotFoundError" hatası dönecektir. Şimdi bulunduğumuz dizinde bulunan "bilgiler.txt" dosyasını açalım.

"""
#%%

file = open("bilgiler.txt","r", encoding="utf-8")
file = open("bilgiler.txt","r", encoding="utf-8")
file.close()
#file = open("bilgiler2.txt","r",encoding="utf-8")  # böyle bir dosya yok . O yüzden FileNotFoundError hatası döner.

#Dosya işlemlerini daha güvenli yazmak try,except bloklarını kullanabilirriz.

try:
    file = open("bilgiler2.txt","r",encoding= "utf-8")
except FileNotFoundError:
    print("Dosya Bulunamadı....")
#Dosya Bulunamadı....

"""
For döngüsü ile okuma
Şöyle bir kullanım dosyamızdaki her bir satırı tek tek okuyacaktır.
"""
#%%
file = open("bilgiler.txt","r",encoding= "utf-8") # Dosyayı okuma kipiyle açıyoruz. Türkçe karaktere dikkat.

for i in file: # Tıpkı listeler gibi dosyanın her bir satırı üzerinde geziniyoruz.
    print(i) # Her bir satırı ekrana basıyoruz.
file.close()
#Burada her bir satırımız boşluklu yazıldı. Bunun nedeni, hem her satır sonunda "\n" karakterinin olması hem de print fonksiyonun bir alt satıra geçmek için boşluk bırakmasıdır. Bunu önlemek için varsayılan değer olarak "\n" karakteri alan end parametresine kendimiz değer verebiliriz.
file = open("bilgiler.txt","r",encoding= "utf-8") # Dosyayı okuma kipiyle açıyoruz. Türkçe karaktere dikkat.

for i in file: # Tıpkı listeler gibi dosyanın her bir satırı üzerinde geziniyoruz.
    print(i,end = "") # Her bir satırı ekrana basıyoruz. end parametresi \n yerine boşluk alacak.
file.close()

"""
read() fonksiyonu
read() fonksiyonu eğer içine hiçbir değer vermezsek bütün dosyamızı okuyacaktır.
"""
#%%
file = open("bilgiler.txt","r",encoding="utf-8")

icerik = file.read() 

print("Dosya İçeriği:\n",icerik,sep ="")

file.close()
#read() fonksiyonuyla bir dosyayı okuduğumuzda dosya imlecimiz dosyanın en sonuna gider ve read() fonksiyonu 2. okuma da artık boş string döner.
#%%
file = open("bilgiler.txt","r",encoding="utf-8")

icerik = file.read() 

print("1. Okuma : Dosya İçeriği:\n",icerik,sep ="")

icerik2 = file.read()


print("2. Okuma : Dosya İçeriği:\n",icerik2,sep ="")

file.close()

"""
readline() fonksiyonu
readline() fonksiyonu her çağrıldığında dosyanın sadece bir satırını okur. Her seferinde dosya imlecimiz (file) bir satır atlayarak devam eder.
"""
#%%
file = open("bilgiler.txt","r",encoding="utf-8")
print(file.readline())
print(file.readline())
print(file.readline())
print(file.readline())
print(file.readline()) 
# Okuyacak herhangi bir şey kalmayınca readline fonksiyonu boş string döner.
file.close()

"""
readlines() fonksiyonu
readlines() fonksiyonu dosyanın bütün satırları bir liste şeklinde döner.
"""
#%%

file = open("bilgiler.txt","r",encoding="utf-8")
file.readlines()
file.close()

"""
Dosyalarda Değişiklik Yapmak
Dosyalarda değişiklik yapmak için 2 farklı yol vardır.

seek() ve write()
Eğer biz bir dosyanın belli bir yerine seek() fonksiyonu ile gidip, write() fonksiyonunu kullanırsak, yazdığımız değerler öncesinde bulunan değerlerin üzerine yazılacaktır. Bunun için hem okuma hem de yazma işlemimizi yapmamızı sağlayan "r+" kipini kullanacağız. İlk önce dosyamızda bilgileri görelim.
"""
#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    print(file.read())

#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file: 
    file.seek(10) # 10. byte
    file.write("Deneme")

#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    print(file.read())

"""
Dosyanın Sonunda Değişiklik Yapmak
Bu işlemlerin en kolayı; 
Dosyaların sonunda değişiklik yapmak için, dosyamızı "a" kipiyle açalım ve sadece dosyanın sonuna write() ile ekleme yapalım.
"""
#%%
with open("bilgiler.txt","a",encoding = "utf-8") as file:
    file.write("İStanbul Beykoz\n") # "append" metoduyla açılan bir dosyanın imleci direk dosyanın sonunda olduğu için sadece write
with open("bilgiler.txt","r",encoding = "utf-8") as file:
    print(file.read())

"""
Dosyanın Başında Değişiklik Yapmak
"bilgiler.txt" dosyamızın başına bir tane satır eklemek için ne yapabiliriz ? Bunun için dosyamızı bütünüyle string halinde alıp daha sonra satırımızı string'in başına eklememiz gerekiyor. Daha sonra dosyanın en başına seek() fonksiyonuyla giderek ,direk write() fonksiyonunu kullanabiliriz.
"""
#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    icerik = file.read()
    print(icerik)
     
#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    icerik = file.read()
    
    icerik = "Python\n" + icerik
    file.seek(0)
    file.write(icerik)
    
#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    icerik = file.read()
    print(icerik)
"""
Dosyanın Ortasında Değişiklik Yapmak
Dosyaların ortasına herhangi bir satır eklemek için ilk olarak her bir satırı liste halinde almamızı sağlayan readlines() fonksiyonunu kullanacağız. Daha sonra bu listenin herhangi bir yerine bir eleman ekleyerek bu listeyi for döngüsü ile dosyaya yazacağız.
"""
#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    print(file.readlines())
"""
Örneğin , "Bugün hava yağmurlu" satırının altına bir tane daha satır eklemek istiyoruz. Bunun için bu listenin 3.indeksine insert() metoduyla bir satır ekleyeceğiz. Daha sonra dosyanın en başına giderek bu listeyi tek tek for döngüsü ile yazacağız.
"""
#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    liste = file.readlines()
    liste.insert(3,"Yağmur yağıyor\n")
    file.seek(0)
    for satır in liste:
        file.write(satır)
#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    icerik = file.read()
    print(icerik)
"""  
Pythonda bir dosyaya listenin içindeki değerleri yazmak için for döngüsü dışında pratik bir fonksiyon bulunuyor. writelines fonksiyonu içine verdiğimiz listeyi dosyaya yazacaktır.
"""
#%%
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    liste = file.readlines()
    liste.insert(3,"Yağmur\n")
    file.seek(0)
    file.writelines(liste)
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    icerik = file.read()
    print(icerik)

"""
Dosyalarda Kullanılan Fonksiyonlar
Bu derste dosya okuma işlemlerine devam edeceğiz ve dosyalarda kullanılan metodları öğrenmeye çalışacağız.

Dosyaları Otomatik Kapatma
Dosyalarda işlemlerimiz bittiği zaman dosyamızı kapatmamız gerektiğini biliyoruz. Ancak programlamacılık doğası gereği çoğu zaman dosyaları kapatmayı unutabiliriz. Bunun için Pythonda dosyalarda işimiz bitince otomatik kapatma özelliği bulunuyor. Bundan sonra Pythonda dosya işlemlerimizi şu blok içinde yapacağız.

with open(dosya_adı,dosya_kipi) as file:
                    Dosya işlemleri
"""
#%%
with open("bilgiler.txt","r",encoding = "utf-8") as file:
    for i in file:
        print(i)
#Eğer dosya işlemlerini bu blok içinde yaparsak işlemimiz bittiği zaman dosyamız otomatik olarak kapanacaktır.
"""        
Dosyaları İleri Geri Sarmak
Dosyaları okurken sadece dosyanın en başından başlayıp, dosya imlecimiz okuma işleminin sonunda dosyanın en sonuna gidiyordu. Ancak biz çoğu zaman dosya imlecini (file) dosyanın herhangi bir yerine götürmek isteyebiliriz. Bunun için Pythondaki seek() fonksiyonunu kullanacağız. Ancak ondan önce dosya imlecinin hangi byteda olduğunu söyleyen tell() fonksiyonuna bakalım.
"""
#%%
with open("bilgiler.txt","r",encoding = "utf-8") as file:
    print(file.tell())

"""
Şu anda hiçbir işlem yapmadığımız için tell() fonksiyonu dosyanın en başında (0. byteda) olduğumuzu söyledi. Peki bir dosya imlecini dosyanın 20.byte'ına götürmek için ne yapacağız ? Bunun için de seek() fonksiyonunu kullanacağız.
"""
#%%
with open("bilgiler.txt","r",encoding = "utf-8") as file:
    file.seek(20) # 20.byte götürdük.
    print(file.tell()) 
"""
Peki biz bir dosyanın belirli bir byte'ına(karakter) gidip sadece belli sayıda karakteri nasıl okuyacağız ? Eğer biz read() fonksiyonuna bir sayı değeri verirsek sadece o sayı değeri kadar alanı okuyacaktır.
"""
#%%
with open("bilgiler.txt","r",encoding = "utf-8") as file:
    file.seek(5) # 5.byte gidiyoruz.
    icerik = file.read(10)  # 10 karakteri okuyoruz.
    print(icerik)
    print(file.tell())

#%%
with open("bilgiler.txt","r",encoding = "utf-8") as file:
    file.seek(5) # 5.byte gidiyoruz.
    icerik = file.read(10)  # 10 karakteri okuyoruz.
    print(icerik)
    file.seek(0)
    icerik2 = file.read(6)
    print(icerik2)
#Dosyalarda herhangi bir yere gidip istediğimiz kadar karakteri okuyabiliyoruz. 


#Örnek hesaplama.py
def not_hesapla(satır):


    satır = satır[:-1]

    liste = satır.split(",")

    isim = liste[0]

    not1 = int(liste[1])

    not2 = int(liste[2])

    not3 = int(liste[3])

    son_not = not1 * (3/10) + not2 * (3/10) + not3 * (4/10)

    if (son_not >= 90):

        harf = "AA"
    elif (son_not >= 85):
        harf = "BA"
    elif (son_not >= 80):
        harf = "BB"
    elif (son_not >= 75):
        harf = "CB"
    elif (son_not >= 70):
        harf = "CC"
    elif (son_not >= 65):
        harf = "DC"
    elif (son_not >= 60):
        harf = "DD"
    elif (son_not >= 55):
        harf = "FD"
    else:
        harf = "FF"

    return isim + "------------------> " + harf + "\n"

with open("dosya.txt","r",encoding= "utf-8") as file:

    eklenecekler_listesi = []

    for i in file:

        eklenecekler_listesi.append(not_hesapla(i))

    with open("notlar.txt","w",encoding="utf-8") as file2:

        for i in eklenecekler_listesi:
            file2.write(i)

""""
ÖDEVLER
Programlama Ödevi - Dosya İşlemleri
Proje 1
Bir sınıfın harf notlarını hesapladığımız programı geliştirerek kalanları "kalanlar.txt" dosyasında ve geçenleri "geçenler.txt" dosyasına yazmaya çalışın.

Proje 2
"futbolcular.txt" şeklinde bir dosya oluşturun ve içine Galatasaray,Fenerbahçe ve Beşiktaşta oynayan futbolcuları rastgele yerleştirin. Bu dosyadan herbir takımın futbolcularını ayırarak "gs.txt" , "fb.txt", "bjk.txt" şeklinde 3 farklı dosyaya yazın.

"futbolcular.txt" dosyasının başlangıç hali şu şekilde olsun.

                Fernando Muslera,Galatasaray
                Atiba Hutchinson,Beşiktaş
                Simon Kjaer,Fenerbahçe
                           //
                           //
                           //
                           //
                           //
"""