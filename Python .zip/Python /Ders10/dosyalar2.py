# -*- coding: utf-8 -*-
"""
Created on Sun May 12 14:14:29 2019

@author: Gözde Mihran Altınsoy


#file=open("deneme.txt","a")
file=open("deneme.txt","r+")
file.seek(19)
file.write("Ece\n")
file.close()
"""

file = open("bilgiler.txt","w",encoding="utf-8")
file.write("Gözde Mihran Altınsoy\n")
file.close() 

file = open("bilgiler.txt","a",encoding="utf-8")
file.write("İstanbul\n") 
file.write("Bugün hava güneşli\n")
file.close()

file = open("bilgiler.txt","r",encoding= "utf-8")
icerik=[]
for i in file:
    icerik.append(i.split("\n")[0])
print(icerik)
liste=[]
print("\nFor ile dosyayı ekrana yazdırıyoruz...")
for i in icerik:
    liste.append(i.split(" "))
    print(i,end="")
print("\n")
print(liste)
print(liste[0]) #Gözde,Mihran,Altınsoy
print(liste[0][0]) #Gözde
print(liste[0][0][0]) #G
liste[0][0]="Gozde"
print(liste[0][0])

file.close()

file = open("bilgiler.txt","r",encoding="utf-8")

icerik = file.read() 
print("Dosya İçeriği:\n",icerik,sep ="")

icerik2 = file.read() 
print("Dosya İçeriği:\n",icerik2,sep ="")
#2.read fonksiyonu imleç son satırda olduğu için boş bir değer döndürür
file.close()

file = open("bilgiler.txt","r",encoding="utf-8")
print(file.readline())
print("\a") #alert (ses çıkarır)
print(file.readline())
print(file.readline())
print(file.readline())

file.seek(0) #imleç 0.indekse yönlendirirdi
print(file.readlines())
file.close()

print("\n")
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    print(file.read())
    
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    icerik=file.read()
    icerik="python\n"+icerik
    file.seek(0)
    file.write(icerik)
    print(file.read())

    
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    #Burada bütün satırları ayrı indexlerde tutar ve ayrı string'ler olarak okuma işlemi yapar
    liste = file.readlines()
    liste.insert(3,"Hava çok güzel\n")
    file.seek(0)
    for satır in liste:
        file.write(satır)
    file.seek(0)
    print(file.read())
    print(liste[0]) #python
    
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    #Burada tek bir string olarak okuma işlemi yapar
    liste2 = file.read()
    print(liste2)
    print(liste2[0]) #p

print("\n")
with open("bilgiler.txt","r+",encoding = "utf-8") as file:
    liste3 = file.readlines()
    liste.insert(3,"Hava çok güzel\n")
    file.seek(0)
    file.writelines(liste3) #listeyi dosyaya yazdırmak için writelines kullanırız
    file.seek(0)
    print(file.read())
    
tuple1=(1,2,3,4,5,6)
file=open("sayilar2.txt","w",encoding = "utf-8")
file.close()
with open("sayilar2.txt","r+",encoding = "utf-8") as file:
    #file.write(str(tuple1))
    for i in tuple1:
        file.write(str(i).split(",")[0])
        file.write("\n")
    file.seek(0)
    print(file.read())
with open("isimler.txt","w",encoding = "utf-8") as file:
    pass
with open("isimler.txt","r+",encoding = "utf-8") as file:
    file.write("Goozde\n")
    file.write("Irem\n")
    file.write("Emir\n")
    file.seek(1)
    file.write("ö") #ö harfi 2 bayt yer kaplar
    file.seek(0) #0.bayt'a gider. yani ilk karakterin öncesine gider
    print(file.read())
    file.seek(9) #9. bayt'ın öncesine imleci yönlendirir
    print(file.read(2)) #2 bayt karakter ekrana basar -> "re" ekrana basar
    print(file.tell()) #şu anda 11.baytta
    #Emir ismindeki "mi" ekrana gelsin
    file.seek(15)
    print(file.read(2))
    #Gözde ismindeki "ö" ekrana gelsin
    file.seek(1)
    print(file.read(1))
    
"""
Soru 1:
0 ile 100 sayıları arasındaki sayıları txt dosyasına aşağıdaki formatta yazdıran python kodlarını yazınız.
0	5	10	15
20	25	30	35
40	45	50	55
....
100
"""

with open("sayilar3.txt","w",encoding = "utf-8") as file:
    pass
sayac=0
with open("sayilar3.txt","r+",encoding = "utf-8") as file:
    for i in range(0,105,5):
        file.write(str(i))
        file.write("\t")
        sayac+=1
        if sayac%4==0:
            file.write("\n")
 

with open("111.txt","r+",encoding = "utf-8") as file:
    liste=file.read()
    liste2=[]
    liste3=[]
    for i in liste:
        liste2.append(i)
    for i in range(0,len(liste)-2,3):
        liste3.append(liste[i]+liste[i+1])
    print(liste2)
    print(liste3)

