# -*- coding: utf-8 -*-
"""
Created on Sat Apr 20 17:11:16 2019

@author: 303UBY00
"""
#%%
sayaç = eval(input("Kaç Tane Olsun   :"))


for i in range(0,sayaç):
    print(sayaç*" ",end ="")
    sayaç-= 1
    for j in range (0,sayaç+1,1):
        print("*",end="")
    print()
#%%
    
def emirhan():
    for i in range(1,6):
        print("Emirhan")
        
def Gözde1(r):
    for i in range(r):
        print(r+1,"Emirhan")

def Gözde2():
    sayı = int(input("Kaç Kez YAzılacak ..."))
    for i in range(sayı):
        print(i+1,"Gözde")
    return sayı

def Fark(a,b):
    if a > b:
        a,b=b,a
    for i in range (a,b+1):
        print("Sayılar  :",i)
    return b-a

def fark(a,b):
    if a > b:
        for i in range (a,b-1,-1):
            print("Sayılar  :",i)
    
    else:
        for i in range (a,b+1,+1):
            print("Sayılar  :",i)
            
def fankşın():
    kelime = input("Kelime Giriniz   :")
    uzunluk = len(kelime)
    
    if uzunluk % 2 == 0:
    
        print(kelime.upper())
        
        
    else:
        print(kelime[0::2])
        
    print(uzunluk)
        
      
def Carpan():
    sayı = int(input("Sayıya Giriniz"))
    for i in range (1,sayı+1):
        if sayı % i == 0:
            print(i)
             
def Asal_Carpan():
     
    sayı = int(input("Sayıya Giriniz"))
    for i in range (1,(int((sayı/2)+1))):
        asal = True
        if sayı % i == 0:
            for j in range(2,i+1):
                asal = False
        if asal == False:
            print(i)
            
        
        
    
#kendine ve 1 e 
            


Asal_Carpan()
        
    
   

        
        
        


        
    
    
    
    
    
    
    

    
    














        

        




