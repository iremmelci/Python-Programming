# -*- coding: utf-8 -*-
"""
Created on Sat Apr 20 17:11:16 2019

@author: 303UBY00
"""
#%%
sayaç = eval(input("Kaç Tane Olsun   :"))


for i in range(0,sayaç):
    print(sayaç*" ",end ="")
    sayaç-= 1
    for j in range (0,sayaç+1,1):
        print("*",end="")
    print()
#%%
    
def emirhan():
    for i in range(1,6):
        print("Emirhan")
        
def Gözde1(r):
    for i in range(r):
        print(r+1,"Emirhan")

def Gözde2():
    sayı = int(input("Kaç Kez YAzılacak ..."))
    for i in range(sayı):
        print(i+1,"Gözde")
    return sayı

def Fark(a,b):
    if a > b:
        a,b=b,a
    for i in range (a,b+1):
        print("Sayılar  :",i)
    return b-a

def fark(a,b):
    if a > b:
        for i in range (a,b-1,-1):
            print("Sayılar  :",i)
    
    else:
        for i in range (a,b+1,+1):
            print("Sayılar  :",i)
            
def fankşın():
    kelime = input("Kelime Giriniz   :")
    uzunluk = len(kelime)
    
    if uzunluk % 2 == 0:
    
        print(kelime.upper())
        
        
    else:
        print(kelime[0::2])
        
    print(uzunluk)
        
      
def Carpan():
    sayı = int(input("Sayıya Giriniz"))
    for i in range (1,sayı+1):
        if sayı % i == 0:
            print(i)
             
def Asal_Carpan():
     
    sayı = int(input("Sayıya Giriniz"))
    for i in range (1,(int((sayı/2)+1))):
        asal = True
        if sayı % i == 0:
            for j in range(2,i+1):
                asal = False
        if asal == False:
            print(i)
            

def sayı(x):
    return x

emirk = lambda x:x

print(emirk(5))


print(sayı(5))
        
#%% 

def kare(x):

    return x*x

kare1 = lambda x:x*x

print(kare(4))

print(kare1(4))

 

def üsalma(a,b):
    return a**b

üsal = lambda a,b:a**b

print(üsalma(5,4))

print(üsal(5,4))


def neg(x):
    if x > 0:
        return x*x
    else:
        return -1*x
    
negatif = lambda x: x*x if x > 0 else -1*x


print(neg(10))

print(negatif(10))
#%%  

tek_cift = lambda x:print("X çifttir") if x % 2 == 0 else print("X Tektir")

tek_cift(int(input("Sayı Giriniz...")))
#%%
bölen = lambda x,y:print(0) if y == 0 else print("Bölüm =",x/y)

bölen(5,3.33)
#%%
def fonk():
    try:
        a,b = int(input("İlk Sayıyı Gir")),int(input("İkinci sayıyı Gir"))
        print(a/b)
    
    except ZeroDivisionError:
        print("Sayı 0 a Bölünmez")
        fonk()
    except ValueError:
        print("Hatalı Argüman Girişi Kral")
        fonk()
        
    except OverflowError:
        print("Sonuç Çok Büyük Kral")
        fonk()
fonk() 

#%%

isim = "Emir"
print(isim)
liste = list(isim)
print(liste)
kelime = "".join(liste)
print(kelime)


#%%
isim = input("Kelime Giriniz    :")

liste = list(isim)

print(liste)

kelime = ""
x = len(liste)
for i in range(0,x):
    kelime = kelime + liste[i]
print(kelime)
#%%

def emr():
    try:
        isim = input("Kelime Giriniz    :")

        liste = list(isim)

        print(liste)

        kelime = ""
        x = len(liste)
        for i in range(0,x):
            kelime = kelime + liste[i]
            print(kelime)
            
    except:
        if isim == int:
            print("Sayi Girme   :")
    
#%%

liste = [10,5,2,6,8,7]

liste.sort()
print(liste)
#%%

def Sırala():
    liste = [10,5,2,6,8,7]
    x = len(liste)
    for i in range (0,x-1):
            for j in range(i+1,x):
                if liste[i] > liste[j]:
                    liste[i],liste[j] = liste[j],liste[i]
    print(liste)
    

Sırala()
#%%
def Eksilt():
    liste = [5,6,-2,4,-3,7,-6]
    print(liste)
    x = len(liste)
    print(x)
    i = 0
    while i < x:
        if liste[i] < 0:
            liste.__delitem__(i)
            print(liste[i])
        i = i + 1
    print(liste)
      
Eksilt()
            






    
   
        
    

        
        
    
    

    
    
        

    
    
    
    
    
        
    




     
    
    
   

        
        
        


        
    
    
    
    
    
    
    

    
    














        

        
























