# -*- coding: utf-8 -*-
"""
Created on Sun May 26 15:48:44 2019

@author: uby1
"""
from tkinter import *

class Toplam:
    def __init__(self,master):
        self.deger=IntVar()
        #Variable
        self.giris=Entry(textvariable=self.deger)
        self.giris.pack()
        Button(text='Goster',command=self.goster).pack()
        self.yaz=Label()
        self.yaz.pack()
        
    def goster(self):
        self.yaz.config(text=self.deger.get())
        self.giris.delete(0,END)
pencere=Tk()
yeni=Toplam(pencere)
mainloop()
        
        