# -*- coding: utf-8 -*-
"""
Created on Sun May 26 18:02:24 2019

@author: 303UBY00
"""

from tkinter import * 
class Toplam:
    def __init__(self,master):
        self.değer=IntVar()
        self.değer2=IntVar()
        self.varsarı=IntVar()
        self.varmor=IntVar()
        
        self.giriş=Entry(textvariable=self.değer)                
        
        self.giriş2=Entry(textvariable=self.değer2)
        Label(text='sayı 1').pack()
        self.giriş.pack()
        Label(text='sayı 2').pack()
        self.giriş2.pack()
        self.yaz=Label(width=10)
        self.yaz.pack()
        
        self.sarı=Checkbutton(text='sarı',variable=self.varsarı,command=self.sarıboya)
        self.sarı.pack()
        self.mor=Checkbutton(text='mor',variable=self.varmor,command=self.morboya)
        self.mor.pack()
        Button(text='Topla',command=self.topla,width=10).pack(side=LEFT)
        Button(text='Çıkar',command=self.çıkar,width=10).pack(side=LEFT)
        Button(text='Çarp',command=self.çarp,width=10).pack(side=LEFT)
        Button(text='Böl',command=self.böl,width=10).pack(side=LEFT)
        
    def sarıboya(self):
        if self.varsarı.get()==1:
            self.yaz.config(bg='yellow')
        else:
            self.yaz.config(bg='gray95')
    def morboya(self):
        if self.varmor.get()==1:
            self.yaz.config(bg='magenta')
        else:
            self.yaz.config(bg='gray95')
    def göster(self):
        self.yaz.config(text=self.değer.get()+self.değer2.get())
        self.sil()
    def topla(self):
        self.yaz.config(text=self.değer.get()+self.değer2.get())
        self.sil()
    
    def çıkar(self):
        self.yaz.config(text=self.değer.get()-self.değer2.get())
    
        self.sil()

    def çarp(self):
        self.yaz.config(text=self.değer.get()*self.değer2.get())
        self.sil()
 
    def böl(self):
        self.yaz.config(text=self.değer.get()/self.değer2.get())
        self.sil()

    def sil(self):
        self.giriş.delete(0,END)
        self.giriş2.delete(0,END)
pencere=Tk()
yeni=Toplam(pencere)
mainloop()