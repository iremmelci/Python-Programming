# -*- coding: utf-8 -*-
"""
Created on Sun May 26 14:15:03 2019

@author: uby1
"""

from tkinter import *
pencere=Tk()
pencere.geometry('300x500')
#genişlik : 300, yükseklik : 500
#tanımlanmazsa (standart) 200x200

def tikla():
    pass
def kapat():
    lbl['text']='Güle güle'
    kapat2['state']='disabled' #Düğmeyi pasif yaptık, yani artık düğmeye tıklanamaz, basılamaz
    pencere.after(1000,pencere.destroy)
    

lbl=Label(text='Merhaba')
lbl.pack()
düğme=Button(text="Tıkla",command=tikla)
düğme.pack()
kapat1=Button(text="Çık",command=pencere.destroy)
kapat1.pack()
kapat2=Button(text="Kapat",command=kapat)
kapat2.pack()
pencere.protocol('WM_DELETE_WINDOW',kapat)
pencere.mainloop()