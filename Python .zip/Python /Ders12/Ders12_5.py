# -*- coding: utf-8 -*-
"""
Created on Sun May 26 16:02:27 2019

@author: uby1
"""

from tkinter import *

class Toplam:
    def __init__(self,master):
        self.deger=IntVar()
        self.deger2=IntVar()
        #Variable
        self.giris=Entry(textvariable=self.deger)
        self.giris2=Entry(textvariable=self.deger2)
        self.giris.pack()
        self.giris2.pack()
        Button(text='Goster',command=self.goster).pack()
        self.yaz=Label()
        self.yaz.pack()
        
    def goster(self):
        self.yaz.config(text=self.deger.get()+self.deger2.get())
        self.giris.delete(0,END)
        self.giris2.delete(0,END)
pencere=Tk()
yeni=Toplam(pencere)
mainloop()