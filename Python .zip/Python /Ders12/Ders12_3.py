# -*- coding: utf-8 -*-
"""
Created on Sun May 26 15:20:39 2019

@author: uby1
"""

from tkinter import *

pencere=Tk()
pencere.title('Kullanıcı Girişi')
pencere.geometry('300x300')
"""
username=Label(text='Username')
username.pack()
user=Entry()
user.pack()
password=Label(text='Password')
password.pack()
pas=Entry()
pas.pack()
"""
Label(pencere,text='Username').grid(row=0,column=0)
Entry(pencere).grid(row=0,column=1)
Label(pencere,text='Password').grid(row=1,column=0)
Entry(pencere).grid(row=1,column=1)
Button(pencere,text="Login",width=20).grid(row=2,column=0,columnspan=2)
Label(pencere,text='Durum',width=10,height=10,fg='yellow',bg='gray').grid(sticky='W',columnspan=2)
pencere.mainloop()