# -*- coding: utf-8 -*-
"""
Created on Sun May 26 14:43:09 2019

@author: uby1
"""

from tkinter import *


class Pencere(Tk):
    
    def __init__(self):
        super().__init__()
        self.protocol('WM_DELETE_WINDOW',self.cikis)
        self.lbl=Label(text='Merhaba')
        self.lbl.pack()
        self.btn=Button(text='Tıkla',command=self.yazdir)
        self.btn.pack()
    def cikis(self):
        self.lbl['text']='Hoşçakal'
        self.after(1000,self.destroy)
    def yazdir(self):
        self.lbl['text']='İrem'

pencere=Pencere()
pencere.mainloop()