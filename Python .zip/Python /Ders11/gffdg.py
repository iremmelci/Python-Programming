import sqlite3

con = sqlite3.connect("öğrenciler.db")
cursor = con.cursor()
def tablo_oluştur():
    cursor.execute("CREATE TABLE IF NOT EXISTS kullanıcı(no INT,ad TEXT,ortalama INT)")
    con.commit()
def değerekle(no,ad,ortalama):
    cursor.execute("INSERT INTO öğrenciler VALUES(?,?,?),(no,ad,ortalama,)")
    con.commit()
def güncelle():
    numara=int(input("güncellenecek numarayı giriniz: "))
    alan=int(input("güncellenecek alanı seçiniz . 1=adı , 2=ortalama , 3=ad ve ortalama"))
    if alan==1:
        cursor.execute("UPDATE kullanıcı SET ad=? WHERE no=?",(ad,numara))
    elif alan==2:
        cursor.execute("UPDATE kullanıcı SET ortalama=? WHERE no=?", (ortalama,numara))
    elif alan==3:
        cursor.execute("UPDATE kullanıcı SET ad=?, ortalama=? WHERE no=?", (ad,ortalama,numara))
    con.commit()
tablo_oluştur()
no=int(input("öğrenci no: "))
ad=input("adı: ")
ortalama=int(input("ortalama: "))
güncelle()

değerekle()
con.close()