import sqlite3

con=sqlite3.connect("çalışanlar.db")
cursor=con.cursor()
def tablo_oluştur():
    cursor.execute("CREATE TABLE IF NOT EXISTS kullanıcı(no INT,ad TEXT,maaş INT)")
    con.commit()
def verilerigöster():
    cursor.execute("SELECT * FROM kullanıcı")
    liste=cursor.fetchall()
    for i in liste:
        print(i)
def verilerigöster2():
    cursor.execute("SELECT ad,maaş FROM kullanıcı ")
    listee=cursor.fetchall()
    for i in listee:
        print(i)
def veriekle():
    cursor.execute("INSERT INTO kullanıcı VALUES(1,'irem',300)")
    con.commit()
def veriekle2(no,adı,maaş):
    cursor.execute("INSERT INTO kullanıcı VALUES(?,?,?)",(no,adı,maaş))
    con.commit()

def veriekle3(adı):
    cursor.execute("SELECT * FROM kullanıcı WHERE ad=?",(adı,))
    liste=cursor.fetchall()
    for i in liste:
        print(i)
def verigüncelle():
    sayı=int(input("güncellenecek personel no: "))
    yeniad=input("ad: ")
    yenimaaş=int(input("maaş: "))
    cursor.execute("UPDATE kullanıcı SET ad=?, maaş=? WHERE no=?",(yeniad,yenimaaş,sayı))
    con.commit()
def verisil():
    numara=int(input("silinecek personelin nosu: "))
    cursor.execute("DELETE FROM kullanıcı WHERE no=?",(numara,))
    con.commit()

tablo_oluştur()
veriekle()
#no=int(input("personel no: "))
#adı=input("personel adı: ")
#maaş=int(input("personel maaşı: "))
#veriekle2(no,adı,maaş)
verilerigöster()
verisil()
verilerigöster()
verilerigöster2()
#adı=input("kullanıcı adı: ")
#veriekle3(adı)
#verigüncelle()


con.close()